//
//  ViewController.swift
//  faceID
//
//  Created by Amam Pratap Singh on 29/01/23.
//

import UIKit
import AVKit
import Vision
import AudioToolbox

class ViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {

    @IBOutlet var lockImage: UIImageView!
    @IBOutlet var unlockImage: UIImageView!
    @IBOutlet var blurEffectView: UIVisualEffectView!
    @IBOutlet var faceIdText: UILabel!
    @IBOutlet var enterPasscodeText: UILabel!
    @IBOutlet var circleFillStackView: UIStackView!
    @IBOutlet var midNumberStackView: UIStackView!
    @IBOutlet var leftNumberStackView: UIStackView!
    @IBOutlet var rightNumberStackView: UIStackView!
    @IBOutlet var firstBlock: UIView!
    @IBOutlet var secondBlock: UIView!
    @IBOutlet var thirdBlock: UIView!
    @IBOutlet var forthBlock: UIView!
    @IBOutlet var fifthBlock: UIView!
    @IBOutlet var sixthBlock: UIView!
    @IBOutlet var one: UIButton!
    @IBOutlet var four: UIButton!
    @IBOutlet var seven: UIButton!
    @IBOutlet var two: UIButton!
    @IBOutlet var five: UIButton!
    @IBOutlet var eight: UIButton!
    @IBOutlet var zero: UIButton!
    @IBOutlet var three: UIButton!
    @IBOutlet var six: UIButton!
    @IBOutlet var nine: UIButton!


    private let captureSession = AVCaptureSession()
    private var isScanned: Bool = false
    private var borderColour: UIColor = .white
    private var borderWidth: CGFloat = 1.0
    private var textFilledCheck: [Bool] = [false, false, false, false, false, false]
    private var passcode: String = ""
    private var currentPointer = 0

    override func viewDidLoad() {
        super.viewDidLoad()

        configDependency()
        configPasscodeCircles(colour: borderColour, width: borderWidth)
        configNumberCircles(colour: borderColour, width: borderWidth)
    }

//  Config Dependencies
    private func configDependency() {
        faceIdText.isHidden = true
        enterPasscodeText.isHidden = true
        circleFillStackView.isHidden = true
        midNumberStackView.isHidden = true
        leftNumberStackView.isHidden = true
        rightNumberStackView.isHidden = true
        unlockImage.alpha = 0
        let gestureReconiser = UITapGestureRecognizer(target: self, action: #selector(startScreening))
        self.view.addGestureRecognizer(gestureReconiser)
    }

//  Start screening your face
    @objc func startScreening() {
        if !isScanned {
            self.isScanned = true
            self.faceIdText.isHidden = false
            loadCameraDetection()
            blurEffectView.effect = UIBlurEffect(style: .dark)
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: {
                self.enablePasscode()
            })
        }
    }

//  Unlock-Lock Button Animation work
    private func unlockScreen() {
        UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5,options: .curveEaseInOut, animations: {
            DispatchQueue.main.async {
                self.lockImage.alpha = 0
                self.lockImage.transform = self.lockImage.transform.translatedBy(x: 0, y: 0)
            }
        }) { (_) in
            UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5,options: .curveEaseInOut, animations: {
                self.unlockImage.alpha = 1
                self.unlockImage.transform = self.unlockImage.transform.translatedBy(x: 0, y: 0)
            })
        }
    }

//  Check the result and unlock screen
    private func checkResult(result: VNConfidence) {
        if result > 90 {
            self.captureSession.stopRunning()
            print("Identified with \(result) confidence level")
            self.unlockScreen()
            DispatchQueue.main.async {
                self.faceIdText.isHidden = true
                self.blurEffectView.effect = UIBlurEffect(style: .light)
                AudioServicesPlayAlertSoundWithCompletion(SystemSoundID(kSystemSoundID_Vibrate)) {}
            }
            self.openSecondScreen()
        }
    }

//  Navigation to second screen
    private func openSecondScreen() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: {
            let openScreenVC = self.storyboard?.instantiateViewController(withIdentifier: "OpenScreenViewController") as! OpenScreenViewController
            openScreenVC.modalPresentationStyle = .fullScreen
            self.present(openScreenVC, animated: true)
        })
    }

//  Disable FaceID and Enable passcode mode
    private func enablePasscode() {
        captureSession.stopRunning()
        lockImage.isHidden = true
        unlockImage.isHidden = true
        faceIdText.isHidden = true
        enterPasscodeText.isHidden = false
        circleFillStackView.isHidden = false
        midNumberStackView.isHidden = false
        leftNumberStackView.isHidden = false
        rightNumberStackView.isHidden = false
    }

//     PASS CODE FUNCTIONS
//  Check button and append passcode
    private func checkAndFill(buttonInfo: ButtonInfo) {
        switch buttonInfo {
        case .one:
            passcode.append(ButtonInfo.one.rawValue)
        case .two:
            passcode.append(ButtonInfo.two.rawValue)
        case .three:
            passcode.append(ButtonInfo.three.rawValue)
        case .four:
            passcode.append(ButtonInfo.four.rawValue)
        case .five:
            passcode.append(ButtonInfo.five.rawValue)
        case .six:
            passcode.append(ButtonInfo.six.rawValue)
        case .seven:
            passcode.append(ButtonInfo.seven.rawValue)
        case .eight:
            passcode.append(ButtonInfo.eight.rawValue)
        case .nine:
            passcode.append(ButtonInfo.nine.rawValue)
        case .zero:
            passcode.append(ButtonInfo.zero.rawValue)
        }
    }

//  Check and fill Circles
    private func checkAndFillCircle() {
        currentPointer = 0
        for val in textFilledCheck {
            currentPointer += 1
            if !val {
                textFilledCheck[currentPointer - 1] = true
                if currentPointer == 1 {
                    firstBlock.backgroundColor = UIColor.white
                    break
                } else if currentPointer == 2 {
                    secondBlock.backgroundColor = UIColor.white
                    break
                } else if currentPointer == 3 {
                    thirdBlock.backgroundColor = UIColor.white
                    break
                } else if currentPointer == 4 {
                    forthBlock.backgroundColor = UIColor.white
                    break
                } else if currentPointer == 5 {
                    fifthBlock.backgroundColor = UIColor.white
                    break
                } else if currentPointer == 6 {
                    sixthBlock.backgroundColor = UIColor.white
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
                        self.checkPasscode(password: self.passcode)
                    })
                    break
                }
            }
        }
    }

//  Check passcode is correct or not
    private func checkPasscode(password: String) {
        if password == "onetwothreefourfivesix" {
            let openScreenVC = self.storyboard?.instantiateViewController(withIdentifier: "OpenScreenViewController") as! OpenScreenViewController
            openScreenVC.modalPresentationStyle = .fullScreen
            self.present(openScreenVC, animated: true)
        } else {
            let alert = UIAlertController(title: "Invalid Passcode", message: "", preferredStyle: .alert)
            self.present(alert, animated: true, completion: nil)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5 , execute: {
                alert.dismiss(animated: true, completion: nil)
            })
            print("Incorrect")
        }
        passcode = ""
        textFilledCheck = [false, false, false, false, false, false]
        firstBlock.backgroundColor = UIColor.systemMint
        secondBlock.backgroundColor = UIColor.systemMint
        thirdBlock.backgroundColor = UIColor.systemMint
        forthBlock.backgroundColor = UIColor.systemMint
        fifthBlock.backgroundColor = UIColor.systemMint
        sixthBlock.backgroundColor = UIColor.systemMint
    }

    @IBAction func didTapTwoButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .two)
        checkAndFillCircle()
    }

    @IBAction func didTapFiveButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .five)
        checkAndFillCircle()
    }

    @IBAction func didTapEightButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .eight)
        checkAndFillCircle()
    }

    @IBAction func didTapZeroButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .zero)
        checkAndFillCircle()
    }

    @IBAction func didTapOneButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .one)
        checkAndFillCircle()
    }

    @IBAction func didTapFourButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .four)
        checkAndFillCircle()
    }

    @IBAction func didTapSevenButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .seven)
        checkAndFillCircle()
    }

    @IBAction func didTapThreeButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .three)
        checkAndFillCircle()
    }

    @IBAction func didTapSixButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .six)
        checkAndFillCircle()
    }

    @IBAction func didTapNineButton(_ sender: UIButton) {
        checkAndFill(buttonInfo: .nine)
        checkAndFillCircle()
    }

}

extension ViewController {
//  Load camera for capturing face
    private func loadCameraDetection() {
        captureSession.sessionPreset = .photo
        guard let captureDevice = AVCaptureDevice.default(.builtInWideAngleCamera ,for: .video, position: .front) else { return }
        guard let input = try? AVCaptureDeviceInput(device: captureDevice) else { return }
        captureSession.addInput(input)
        captureSession.startRunning()
        let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        view.layer.addSublayer(previewLayer)

//      Capturing the data from the video frame and adding delegate.
        let dataOutput = AVCaptureVideoDataOutput()
        dataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(dataOutput)
    }

//  Detecting your face
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
//      Image
        guard let pixelBuffer: CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

//      Model
        guard let model = try? VNCoreMLModel(for: DogCatHorse().model) else { return }

//      Request
        let request = VNCoreMLRequest(model: model) { finishRequest, error in
            guard let results = finishRequest.results else { return }
            let firstValue = "\(results[0])"
            if firstValue.contains("Cat") {
                self.checkResult(result: results[0].confidence * 100)
            }
        }

//      Handler
        try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
    }
}

extension ViewController {
    private func configPasscodeCircles(colour: UIColor, width: CGFloat) {
        firstBlock.layer.cornerRadius = (firstBlock.frame.size.width < firstBlock.frame.size.height) ?  firstBlock.frame.size.width / 2.0 : firstBlock.frame.size.height / 2.0
        firstBlock.layer.borderColor = colour.cgColor
        firstBlock.layer.borderWidth = width

        secondBlock.layer.cornerRadius = (secondBlock.frame.size.width < secondBlock.frame.size.height) ?  secondBlock.frame.size.width / 2.0 : secondBlock.frame.size.height / 2.0
        secondBlock.layer.borderColor = colour.cgColor
        secondBlock.layer.borderWidth = width

        thirdBlock.layer.cornerRadius = (thirdBlock.frame.size.width < thirdBlock.frame.size.height) ?  thirdBlock.frame.size.width / 2.0 : thirdBlock.frame.size.height / 2.0
        thirdBlock.layer.borderColor = colour.cgColor
        thirdBlock.layer.borderWidth = width

        forthBlock.layer.cornerRadius = (forthBlock.frame.size.width < forthBlock.frame.size.height) ?  forthBlock.frame.size.width / 2.0 : forthBlock.frame.size.height / 2.0
        forthBlock.layer.borderColor = colour.cgColor
        forthBlock.layer.borderWidth = width

        fifthBlock.layer.cornerRadius = (fifthBlock.frame.size.width < fifthBlock.frame.size.height) ?  fifthBlock.frame.size.width / 2.0 : fifthBlock.frame.size.height / 2.0
        fifthBlock.layer.borderColor = colour.cgColor
        fifthBlock.layer.borderWidth = width

        sixthBlock.layer.cornerRadius = (sixthBlock.frame.size.width < sixthBlock.frame.size.height) ?  sixthBlock.frame.size.width / 2.0 : sixthBlock.frame.size.height / 2.0
        sixthBlock.layer.borderColor = colour.cgColor
        sixthBlock.layer.borderWidth = width
    }

    private func configNumberCircles(colour: UIColor, width: CGFloat) {
        one.layer.cornerRadius = (one.frame.size.width < one.frame.size.height) ? one.frame.size.width / 2.0 : one.frame.size.height / 2.0
        one.tintColor = colour
        one.layer.borderColor = colour.cgColor
        one.layer.borderWidth = width

        two.layer.cornerRadius = (two.frame.size.width < two.frame.size.height) ? two.frame.size.width / 2.0 : two.frame.size.height / 2.0
        two.layer.borderColor = colour.cgColor
        two.layer.borderWidth = width
        two.tintColor = colour

        three.layer.cornerRadius = (three.frame.size.width < three.frame.size.height) ? three.frame.size.width / 2.0 : three.frame.size.height / 2.0
        three.layer.borderColor = colour.cgColor
        three.layer.borderWidth = width
        three.tintColor = colour

        four.layer.cornerRadius = (four.frame.size.width < four.frame.size.height) ? four.frame.size.width / 2.0 : four.frame.size.height / 2.0
        four.layer.borderColor = colour.cgColor
        four.layer.borderWidth = width
        four.tintColor = colour

        five.layer.cornerRadius = (five.frame.size.width < five.frame.size.height) ? five.frame.size.width / 2.0 : five.frame.size.height / 2.0
        five.layer.borderColor = colour.cgColor
        five.layer.borderWidth = width
        five.tintColor = colour

        six.layer.cornerRadius = (six.frame.size.width < six.frame.size.height) ? six.frame.size.width / 2.0 : six.frame.size.height / 2.0
        six.layer.borderColor = colour.cgColor
        six.layer.borderWidth = width
        six.tintColor = colour

        seven.layer.cornerRadius = (seven.frame.size.width < seven.frame.size.height) ? seven.frame.size.width / 2.0 : seven.frame.size.height / 2.0
        seven.layer.borderColor = colour.cgColor
        seven.layer.borderWidth = width
        seven.tintColor = colour

        eight.layer.cornerRadius = (eight.frame.size.width < eight.frame.size.height) ? eight.frame.size.width / 2.0 : eight.frame.size.height / 2.0
        eight.layer.borderColor = colour.cgColor
        eight.layer.borderWidth = width
        eight.tintColor = colour

        nine.layer.cornerRadius = (nine.frame.size.width < nine.frame.size.height) ? nine.frame.size.width / 2.0 : nine.frame.size.height / 2.0
        nine.layer.borderColor = colour.cgColor
        nine.layer.borderWidth = width
        nine.tintColor = colour

        zero.layer.cornerRadius = (zero.frame.size.width < zero.frame.size.height) ? zero.frame.size.width / 2.0 : zero.frame.size.height / 2.0
        zero.layer.borderColor = colour.cgColor
        zero.layer.borderWidth = width
        zero.tintColor = colour
    }
}
